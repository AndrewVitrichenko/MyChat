package com.rockwellstudios.mychat.ui.main.entities

data class User (var userName : String,var email : String, var userPicture : String,var hasLoggedIn : Boolean)