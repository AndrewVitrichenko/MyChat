package com.rockwellstudios.mychat.base

/**
 * Created by user on 23.03.18.
 */
interface BasePresenter {

    fun attach()

    fun detach()
}