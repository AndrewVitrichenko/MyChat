package com.rockwellstudios.mychat.common

/**
 * Created by user on 23.03.18.
 */

const val USER_TOKEN = "user_token"
const val USER_EMAIL = "user_email"
const val USER_NAME = "user_name"
const val USER_PICTURE = "user_picture"

const val INBOX_SCREEN = 1
const val ADD_FRIENDS_SCREEN = 2
const val PROFILE_SCREEN = 3


