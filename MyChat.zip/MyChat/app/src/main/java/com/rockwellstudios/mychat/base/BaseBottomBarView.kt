package com.rockwellstudios.mychat.base

interface BaseBottomBarView {

    fun setBottomItemChecked(itemId : Int)
}