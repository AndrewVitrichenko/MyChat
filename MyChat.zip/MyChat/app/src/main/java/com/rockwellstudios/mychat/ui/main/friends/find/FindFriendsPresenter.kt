package com.rockwellstudios.mychat.ui.main.friends.find

class FindFriendsPresenter : FindFriendsContract.Presenter {

    override fun attach() {

    }

    override fun detach() {

    }

}