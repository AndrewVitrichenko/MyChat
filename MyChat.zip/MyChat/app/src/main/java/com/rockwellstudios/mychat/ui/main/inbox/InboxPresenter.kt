package com.rockwellstudios.mychat.ui.main.inbox

class InboxPresenter : InboxContract.Presenter {


    override fun attach() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun detach() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}