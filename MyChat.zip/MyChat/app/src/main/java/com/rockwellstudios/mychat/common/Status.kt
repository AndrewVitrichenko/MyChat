package com.rockwellstudios.mychat.common

abstract class Status {

    companion object{
        const val LOADING = 1
        const val SUCCESS = 2
        const val ERROR = 3
    }
}