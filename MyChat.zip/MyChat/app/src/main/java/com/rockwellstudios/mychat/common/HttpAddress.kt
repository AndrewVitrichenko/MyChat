package com.rockwellstudios.mychat.common

/**
 * Created by user on 23.03.18.
 */

// home windows
const val IP_LOCAL_HOST = "http://192.168.0.101:3000"

// work linux
//const val IP_LOCAL_HOST = "http://192.168.1.83:3000"