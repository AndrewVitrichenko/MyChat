package com.rockwellstudios.mychat.ui.main.friends.requests

class FriendRequestsPresenter : FriendRequestsContract.Presenter {


    override fun attach() {

    }

    override fun detach() {

    }
}