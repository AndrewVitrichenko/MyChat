package com.rockwellstudios.mychat.ui.auth

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.rockwellstudios.mychat.common.USER_TOKEN
import com.rockwellstudios.mychat.ui.auth.data.AuthDataSource
import com.rockwellstudios.mychat.utils.PreferenceDataSource
import javax.inject.Inject

class AuthViewModel @Inject constructor(private val preferenceDataSource: PreferenceDataSource) : ViewModel() {

    private val authState : MutableLiveData<Boolean> = MutableLiveData()

    init {
        checkAuthState()
    }

    private fun checkAuthState() {
        val userId = preferenceDataSource.getString(USER_TOKEN,"")
        userId.let {
            authState.value = it.isEmpty()
        }
    }

    override fun onCleared() {
        super.onCleared()
    }

    fun getAuthState() : MutableLiveData<Boolean> = authState


}