package com.rockwellstudios.mychat.ui.main.friends.user

class UserFriendsPresenter : UserFriendsContract.Presenter {

    override fun attach() {

    }

    override fun detach() {

    }
}