package com.rockwellstudios.mychat.entity

/**
 * Created by user on 23.03.18.
 */
class AuthEntities {

    data class AuthBody(var userName : String,var email : String, var password : String,var userPicture : String,
                        var token : String)

}