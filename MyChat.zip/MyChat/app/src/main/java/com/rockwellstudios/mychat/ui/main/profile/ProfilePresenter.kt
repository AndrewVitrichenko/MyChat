package com.rockwellstudios.mychat.ui.main.profile

import com.rockwellstudios.mychat.base.BasePresenter
import com.rockwellstudios.mychat.base.BaseView

class ProfilePresenter : ProfileContract.Presenter  {


    override fun attach() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun detach() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


}